export const placeholderChar = '_'
export const strFunction = 'function'
