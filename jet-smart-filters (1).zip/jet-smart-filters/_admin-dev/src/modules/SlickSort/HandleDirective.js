// Export Sortable Element Handle Directive
export const HandleDirective = {
	beforeMount(el) {
		el.sortableHandle = true;
	},
};
