<?php
/**
 * Active filter label template
 */

?>
<div class="jet-active-filter__label">/% $value %/<span class="jet-active-filter__label-separator">:</span></div>