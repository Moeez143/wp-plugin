<?php
/**
 * Active tag remove template
 */

?>
<div class="jet-active-tag__remove">&times;</div>